// using function

function calcAddition(number1,number2) {
    return number1 + number2;
};
console.log(calcAddition(10,20));

// without function name using variable

const square= function(number) {
    return number*number;
};
console.log(square(2));

// functions

const x=square(4);
console.log(x);


// arrow function
const a=["Manav","Prince","Dilip"];
const a2= a.map(function(s){
    return s.length;
});

console.log("normal way",a2);

const a3= a.map((s) => s.length);

console.log("using arrow function",a3);//[8,6,7,9]