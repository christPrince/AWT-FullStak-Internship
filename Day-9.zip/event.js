function demoOnClick(){
    alert("onclick");
}

function demoOnDblClick(){
    alert("CHAL NIKALLL!!!!")
}

function demoOnfocus(){
    document.getElementById("txtFocus").style.backgroundColor="yellow";
}

function demoOnBlur(){
    document.getElementById("txtBlur").style.backgroundColor="blue";
}

function demoOnKeypress(){
    alert("keypress Done");
}

function demoOnKeypress(){
    alert("keyup Done");
}